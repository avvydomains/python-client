class InvalidKeyException(Exception):
	pass


class DomainExpiredException(Exception):
	pass


class ResolverNotSetException(Exception):
	pass



